'use strict';

var _server = require('./server');

var _server2 = _interopRequireDefault(_server);

function _interopRequireDefault(obj) { 
     console.log("=================START JA==============");
    return obj && obj.__esModule ? obj : { default: obj }; 
}

_server2.default.bootstrap();