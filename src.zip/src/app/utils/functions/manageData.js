"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var splitNumber = exports.splitNumber = function splitNumber(number) {
    return (number.toString() / 100).toFixed(2);
};