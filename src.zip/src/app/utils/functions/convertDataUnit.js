"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var convertKB2MB = exports.convertKB2MB = function convertKB2MB(kb) {
    return (kb / 1024).toFixed(2);
};